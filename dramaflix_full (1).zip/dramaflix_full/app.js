(() => {
  // ---------- UTIL ----------
  const APP = document.getElementById('app');
  const qs = s => document.querySelector(s);
  const qsa = s => Array.from(document.querySelectorAll(s));
  const read = k => JSON.parse(localStorage.getItem(k) || '[]');
  const write = (k, v) => localStorage.setItem(k, JSON.stringify(v));
  const uid = () => Date.now() + Math.floor(Math.random()*999);

  // THEME: follow system by default, allow toggle
  const prefersDark = window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches;
  const savedTheme = localStorage.getItem('df_theme') || (prefersDark ? 'dark' : 'light');
  document.documentElement.setAttribute('data-theme', savedTheme);
  document.getElementById('themeToggle').addEventListener('click', () => {
    const cur = document.documentElement.getAttribute('data-theme');
    const next = cur === 'dark' ? 'light' : 'dark';
    document.documentElement.setAttribute('data-theme', next);
    localStorage.setItem('df_theme', next);
  });

  // ---------- MOCK DATA ----------
  const initialMock = [
    {
      id:1, title:'Pahlawan Senja', rating:8.6, genre:['Action','Fantasy'], country:'KR', year:2023, duration:'45m', poster:'img/p1.jpg', preview:'previews/p1.mp4',
      episodes:[
        {ep:1, src:'videos/sample.mp4', hls:'', subs:[{lang:'id', url:''}]},
        {ep:2, src:'videos/sample.mp4', hls:'', subs:[]}
      ], cast:[{name:'Actor A'},{name:'Actor B'}], status:'ongoing', synopsis:'Drama aksi fantasi di kota senja.'},
    {
      id:2, title:'Cinta Musim Semi', rating:7.9, genre:['Romance'], country:'JP', year:2021, duration:'55m', poster:'img/p2.jpg', preview:'previews/p2.mp4',
      episodes:[{ep:1, src:'videos/sample.mp4', hls:'', subs:[]}], cast:[{name:'Actor X'}], status:'complete', synopsis:'Romansa manis bertemu di musim semi.'}
  ];
  if(!localStorage.getItem('df_mock_dramas')) localStorage.setItem('df_mock_dramas', JSON.stringify(initialMock));

  // ---------- ROUTER ----------
  function getHash(){ return location.hash.slice(1) || '/'; }
  window.addEventListener('hashchange', render);
  if(!location.hash) location.hash = '/';
  render();

  function render(){
    const route = getHash();
    const [path, query] = route.split('?');
    const params = new URLSearchParams(query || '');
    if(path === '/' || path === '') return renderIndex();
    if(path === '/detail') return renderDetail(+params.get('id') || 1);
    if(path === '/player') return renderPlayer(+params.get('id') || 1, +params.get('ep') || 1);
    if(path === '/admin') return renderAdmin();
    APP.innerHTML = '<p>Halaman tidak ditemukan — <a href="#/">kembali</a></p>';
  }

  // ---------- INDEX ----------
  function renderIndex(){
    const dramas = JSON.parse(localStorage.getItem('df_mock_dramas') || '[]');
    APP.innerHTML = `
      <section class="topbar" style="margin-bottom:12px;display:flex;gap:8px;align-items:center">
        <input id="search" placeholder="Cari judul..." style="flex:1;padding:8px;border-radius:8px;border:1px solid #ddd"/>
        <select id="genreFilter"><option value="">Semua Genre</option></select>
        <select id="countryFilter"><option value="">Semua Negara</option></select>
        <select id="yearFilter"><option value="">Semua Tahun</option></select>
        <select id="sortBy">
          <option value="popular">Populer</option>
          <option value="newest">Terbaru</option>
          <option value="ongoing">Ongoing</option>
        </select>
      </section>
      <section id="grid" class="grid"></section>
      <nav id="pagination" class="pagination"></nav>
    `;

    // populate filters
    const all = dramas || [];
    const genres = [...new Set(all.flatMap(d=>d.genre))]; genres.forEach(g=> qs('#genreFilter').insertAdjacentHTML('beforeend', `<option>${g}</option>`));
    const countries = [...new Set(all.map(d=>d.country))]; countries.forEach(c=> qs('#countryFilter').insertAdjacentHTML('beforeend', `<option>${c}</option>`));
    const years = [...new Set(all.map(d=>d.year))].sort((a,b)=>b-a); years.forEach(y=> qs('#yearFilter').insertAdjacentHTML('beforeend', `<option>${y}</option>`));

    function renderGrid(list){
      const grid = qs('#grid'); grid.innerHTML = '';
      list.forEach(d => {
        const el = document.createElement('div'); el.className='card';
        el.innerHTML = `
          <img loading="lazy" src="${d.poster}" alt="${d.title}">
          <h3>${d.title}</h3>
          <div class="meta">⭐ ${d.rating} · ${d.genre.join(', ')} · ${d.year}</div>
          <div style="margin-top:8px"><a href="#/detail?id=${d.id}">Detail</a> · <a href="#/player?id=${d.id}&ep=1">Tonton</a></div>
        `;
        grid.appendChild(el);
      });
    }

    // handlers
    ['search','genreFilter','countryFilter','yearFilter','sortBy'].forEach(id=>{
      qs('#'+id).addEventListener('input', filterAndRender);
    });

    function filterAndRender(){
      let list = (JSON.parse(localStorage.getItem('df_mock_dramas'))||[]);
      const q = qs('#search').value.trim().toLowerCase();
      if(q) list = list.filter(d=>d.title.toLowerCase().includes(q));
      const g = qs('#genreFilter').value; if(g) list = list.filter(d=>d.genre.includes(g));
      const c = qs('#countryFilter').value; if(c) list = list.filter(d=>d.country===c);
      const y = qs('#yearFilter').value; if(y) list = list.filter(d=>String(d.year)===String(y));
      const s = qs('#sortBy').value;
      if(s==='popular') list.sort((a,b)=>b.rating-a.rating);
      if(s==='newest') list.sort((a,b)=>b.year-b.year);
      if(s==='ongoing') list = list.filter(d=>d.status==='ongoing');
      renderGrid(list);
    }
    filterAndRender();
  }

  // ---------- DETAIL ----------
  function renderDetail(id){
    const dramas = JSON.parse(localStorage.getItem('df_mock_dramas') || '[]');
    const drama = dramas.find(d=>d.id===id);
    if(!drama){ APP.innerHTML = '<p>Drama tidak ditemukan <a href="#/">kembali</a></p>'; return; }

    APP.innerHTML = `
      <div class="detail-wrap">
        <aside class="poster-col">
          <img id="poster" class="poster" src="${drama.poster}" alt="poster" />
          <div style="margin-top:8px">
            <button id="favBtn" class="badge">❤ Favorit</button>
            <button id="watchBtn" class="badge">🔖 Watchlist</button>
          </div>
          <div class="info-box" style="margin-top:12px">
            <div><strong>Rating:</strong> ${drama.rating}</div>
            <div><strong>Status:</strong> ${drama.status}</div>
            <div><strong>Durasi:</strong> ${drama.duration}</div>
          </div>
        </aside>
        <section class="content-col">
          <h1 id="title">${drama.title}</h1>
          <p id="synopsis">${drama.synopsis}</p>
          <div class="mini"><strong>Genre:</strong> ${drama.genre.join(', ')} | <strong>Negara:</strong> ${drama.country} | <strong>Tahun:</strong> ${drama.year}</div>

          <h3 style="margin-top:12px">Trailer / Preview</h3>
          <div class="video-wrap"><video id="preview" controls width="100%"><source src="${drama.preview || ''}" type="video/mp4"></video></div>

          <h3 style="margin-top:12px">Daftar Episode</h3>
          <div id="episodeList" class="episode-list"></div>

          <h3 style="margin-top:12px">Pemeran & Kru</h3>
          <div id="castList"></div>

          <h3 style="margin-top:12px">Rekomendasi</h3>
          <div id="reco" class="grid small"></div>
        </section>
      </div>
    `;

    // episodes
    const epsEl = qs('#episodeList');
    drama.episodes.forEach(ep => {
      const div = document.createElement('div'); div.className='ep';
      div.innerHTML = `<strong>Episode ${ep.ep}</strong><div style="margin-top:6px"><a href="#/player?id=${drama.id}&ep=${ep.ep}">Play</a></div>`;
      epsEl.appendChild(div);
    });

    // cast
    qs('#castList').innerHTML = drama.cast.map(c=>`<div class="card" style="display:inline-block;margin-right:6px;padding:6px">${c.name}</div>`).join('');

    // recommendations (others)
    const others = (JSON.parse(localStorage.getItem('df_mock_dramas'))||[]).filter(d=>d.id!==drama.id);
    qs('#reco').innerHTML = others.map(o=>`<div class="card"><img src="${o.poster}"><h4>${o.title}</h4><div class="meta">⭐ ${o.rating}</div><div style="margin-top:6px"><a href="#/detail?id=${o.id}">Detail</a></div></div>`).join('');

    // fav/watchlist toggle
    const favKey='df_fav', wlKey='df_watch';
    const fbtn = qs('#favBtn'), wbtn = qs('#watchBtn');
    function toggle(key, id, btn) {
      const arr = read(key); const exists = arr.includes(id);
      if(exists){ write(key, arr.filter(x=>x!==id)); btn.textContent = btn.dataset.off; } else { arr.push(id); write(key, arr); btn.textContent = btn.dataset.on; }
    }
    fbtn.dataset.on='❤ Favorit'; fbtn.dataset.off='❤ Favorit';
    wbtn.dataset.on='✓ Ditambahkan'; wbtn.dataset.off='🔖 Watchlist';
    fbtn.addEventListener('click', ()=> toggle(favKey, drama.id, fbtn));
    wbtn.addEventListener('click', ()=> toggle(wlKey, drama.id, wbtn));
  }

  // ---------- PLAYER ----------
  function renderPlayer(id, ep){
    const dramas = JSON.parse(localStorage.getItem('df_mock_dramas') || '[]');
    const drama = dramas.find(d=>d.id===id);
    if(!drama){ APP.innerHTML = '<p>Episode tidak ditemukan <a href="#/">kembali</a></p>'; return; }
    const episode = drama.episodes.find(e=>e.ep===ep) || drama.episodes[0];

    APP.innerHTML = `
      <div class="player-shell">
        <header style="margin-bottom:8px"><a href="#/detail?id=${drama.id}">← Kembali</a></header>
        <div class="video-wrap">
          <video id="video" controls crossorigin playsinline style="width:100%;height:auto"></video>
        </div>

        <div class="player-controls" style="margin-top:12px">
          <label>Quality: <select id="qSel"></select></label>
          <label>Sub: <select id="subSel"><option value="">Off</option></select></label>
          <label>Speed: <select id="speedSel"><option>0.5</option><option>0.75</option><option selected>1</option><option>1.25</option><option>1.5</option><option>2</option></select></label>
          <button id="pipBtn">PIP</button>
          <button id="nextBtn">Next ▶</button>
        </div>

        <section class="comments">
          <h4 style="margin-top:12px">Komentar</h4>
          <div class="comment-box"><input id="commentInput" placeholder="Tulis komentar..."/><button id="commentSend">Kirim</button></div>
          <div id="commentList"></div>
        </section>
      </div>
    `;

    const video = qs('#video');
    const qSel = qs('#qSel'), subSel = qs('#subSel'), speedSel = qs('#speedSel'), pipBtn = qs('#pipBtn'), nextBtn = qs('#nextBtn');

    // quality list
    const qualities = [];
    if(episode.hls) qualities.push({label:'HLS', src:episode.hls, hls:true});
    if(episode.src) qualities.push({label:'720p', src:episode.src});
    qualities.forEach(q=> qSel.add(new Option(q.label, q.label)));

    function loadQuality(label){
      const chosen = qualities.find(x=>x.label===label) || qualities[0];
      if(window._hls){ try{ window._hls.destroy(); window._hls = null; } catch(e){} }
      if(chosen && chosen.hls && window.Hls && Hls.isSupported()){
        const hls = new Hls(); window._hls = hls; hls.loadSource(chosen.src); hls.attachMedia(video);
      } else if(chosen) {
        video.src = chosen.src;
      }
      video.play().catch(()=>{});
    }
    if(qualities.length) loadQuality(qualities[0].label);
    qSel.addEventListener('change',(e)=> loadQuality(e.target.value));

    // subtitles
    (episode.subs||[]).forEach(s => subSel.add(new Option(s.lang, s.url)));
    subSel.addEventListener('change', ()=>{
      [...video.querySelectorAll('track')].forEach(t=>t.remove());
      const url = subSel.value; if(!url) return;
      const tr = document.createElement('track'); tr.kind='subtitles'; tr.src=url; tr.default=true; video.appendChild(tr);
    });

    // speed control
    speedSel.addEventListener('change',(e)=> video.playbackRate = Number(e.target.value));

    // Picture-in-Picture
    pipBtn.addEventListener('click', async ()=>{
      try{ if(document.pictureInPictureElement) await document.exitPictureInPicture(); else await video.requestPictureInPicture(); } catch(e){ alert('PIP tidak didukung'); }
    });

    // next episode
    nextBtn.addEventListener('click', ()=> {
      const next = episode.ep + 1; const nex = drama.episodes.find(x=>x.ep===next);
      if(nex) location.hash = `#/player?id=${drama.id}&ep=${next}`; else alert('Tidak ada episode berikutnya');
    });

    // auto next on ended
    video.addEventListener('ended', ()=> {
      const next = episode.ep + 1; const nex = drama.episodes.find(x=>x.ep===next);
      if(nex) location.hash = `#/player?id=${drama.id}&ep=${next}`;
    });

    // comments (localStorage per drama+ep)
    const ck = `comments_${drama.id}_${episode.ep}`;
    if(!localStorage.getItem(ck)) write(ck, []);
    function renderComments(){
      const arr = read(ck);
      qs('#commentList').innerHTML = arr.slice().reverse().map(c=>`
        <div class="card" style="margin-bottom:6px;padding:8px">
          <b>${c.user}</b> · <small style="color:var(--muted)">${new Date(c.t).toLocaleString()}</small>
          <p>${c.text}</p>
          <div><button data-id="${c.id}" class="likeBtn">❤ ${c.likes||0}</button></div>
        </div>
      `).join('');
      qsa('.likeBtn').forEach(b=> b.onclick = ()=> {
        const id = Number(b.dataset.id); const arr = read(ck); const idx = arr.findIndex(x=>x.id===id);
        if(idx>-1){ arr[idx].likes=(arr[idx].likes||0)+1; write(ck,arr); renderComments(); }
      });
    }
    qs('#commentSend').addEventListener('click', ()=>{
      const text = (qs('#commentInput').value||'').trim(); if(!text) return;
      const arr = read(ck); arr.push({id:uid(), user:'Anon', text, t:Date.now(), likes:0}); write(ck,arr); qs('#commentInput').value=''; renderComments();
    });
    renderComments();

    // save history
    const hist = read('df_history'); hist.push({id:drama.id, ep:episode.ep, at:Date.now()}); write('df_history', hist.slice(-100));
  }

  // ---------- ADMIN ----------
  function renderAdmin(){
    APP.innerHTML = `
      <main class="admin-form">
        <h2>Admin - Upload / Tambah Drama</h2>
        <form id="uploadForm">
          <input name="title" placeholder="Judul" required style="width:100%;padding:8px;margin-bottom:6px"/>
          <textarea name="synopsis" placeholder="Sinopsis" style="width:100%;padding:8px;margin-bottom:6px"></textarea>
          <input name="genre" placeholder="Genre (pisah koma)" style="width:100%;padding:8px;margin-bottom:6px"/>
          <input name="country" placeholder="Negara" style="width:100%;padding:8px;margin-bottom:6px"/>
          <input name="year" placeholder="Tahun" style="width:100%;padding:8px;margin-bottom:6px"/>
          <label>Poster: <input type="file" name="poster" accept="image/*" /></label><br/>
          <label>Preview (mp4): <input type="file" name="preview" accept="video/*" /></label><br/>
          <label>Episode file (mp4 or m3u8): <input type="file" name="episode" accept="video/*,.m3u8" /></label><br/>
          <button type="submit" style="margin-top:8px;padding:8px 12px;background:var(--accent);color:#fff;border-radius:8px">Upload (mock)</button>
        </form>
        <section id="manageList" style="margin-top:12px"></section>
      </main>
    `;

    const form = qs('#uploadForm');
    form.addEventListener('submit', async (ev) => {
      ev.preventDefault();
      const fd = new FormData(form);

      let uploaded = false;
      try {
        const res = await fetch('/api/dramas', { method:'POST', body:fd });
        if(res.ok){ alert('Uploaded to server'); uploaded = true; location.reload(); return; }
      } catch(e){ /* no backend */ }

      if(!uploaded){
        const db = JSON.parse(localStorage.getItem('df_mock_dramas') || '[]');
        const obj = {
          id: uid(),
          title: fd.get('title') || 'Untitled',
          synopsis: fd.get('synopsis') || '',
          rating: 0,
          genre: (fd.get('genre') || '').split(',').map(v=>v.trim()).filter(Boolean),
          country: fd.get('country') || 'ID',
          year: Number(fd.get('year') || 2025),
          duration: '45m',
          poster: 'img/p' + uid() + '.jpg',
          preview: '',
          episodes: [],
          cast: [],
          status: 'ongoing'
        };
        db.push(obj);
        localStorage.setItem('df_mock_dramas', JSON.stringify(db));
        alert('Disimpan ke localStorage (mock)');
        location.hash = '/';
      }
    });

    // show existing (local)
    const list = JSON.parse(localStorage.getItem('df_mock_dramas') || '[]');
    qs('#manageList').innerHTML = list.map(d=>`<div class="card" style="margin-bottom:8px;padding:8px"><b>${d.title}</b> — ${d.year} <div><a href="#/detail?id=${d.id}">Lihat</a></div></div>`).join('');
  }

  // initial render called on load by router
})();