DramaFlix - Live Preview Prototype
Files:
- index.html
- style.css
- app.js
- previews/ (contains p1.mp4, p2.mp4 stubs)
- videos/ (sample.mp4 stub)
- img/ (p1.jpg, p2.jpg SVG placeholders)

How to run:
- For full functionality open a local server in the folder:
  npx serve .   OR   python -m http.server 8000
- Open http://localhost:5000 (or port shown)
Notes:
- Video files are placeholders; replace with real MP4/HLS files.
- To enable server upload connect /api/dramas to a backend.
